require('dotenv').config();
require('discord.js');
require('@discordjs/voice')
const { Client, Events, GatewayIntentBits, REST, Routes, SlashCommandBuilder, ChannelType } = require('discord.js');
const { joinVoiceChannel, getVoiceConnection, getVoiceConnections, SpeakingMap, VoiceConnectionStatus, entersState } = require('@discordjs/voice')
const token = process.env.token;
const GUILD_ID = process.env.guildid;
const refDen = process.env.refden;

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});
const rest = new REST({ version: '10' }).setToken(token);

const WebSocket = require('ws');
const wsport = process.env.wssport;
const wss = new WebSocket.Server({ port: wsport });
let wsClient = null;
console.log(`WebSocket server started on port ${wsport}`)

let vcMembers = [];

function sendToWs(data) {
    // Validate input
    if (!data) {
        console.error('Attempted to send empty data');
        return false;
    }

    // Convert to string if it's an object
    const payload = typeof data === 'object' ? JSON.stringify(data) : data;

    if (!wsClient) {
        console.error('WebSocket client not initialized');
        return false;
    }

    if (wsClient.readyState !== WebSocket.OPEN) {
        console.error('WebSocket is not open. ReadyState:', wsClient.readyState);
        return false;
    }

    try {
        wsClient.send(payload);
        console.log('Sent WebSocket message:', payload);
        return true;
    } catch (err) {
        console.error('WebSocket send error:', err, 'Payload:', payload);
        return false;
    }
}

wss.on('connection', (ws) => {
    console.log(`WebSocket client connected.`);
    wsClient = ws;

    const botReadyMsg = {
        type: 'bot_ready',
        username: client.user.tag
    }; sendToWs(JSON.stringify(botReadyMsg));

    if (client.isReady()) {
        const botConnectedToDiscordMsg = {
            type: 'channel_monitored',
            success: true
        }; sendToWs(JSON.stringify(botConnectedToDiscordMsg));

        if (vcMembers.length > 0) {
            console.log(`[EVENT] Re-sending members_update`);
            sendToWs({
                type: 'members_update',
                members: vcMembers
            });
        }
    }

    ws.on('close', () => {
        console.log(`WebSocket client disconnected.`);
        wsClient = null;
    });

    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
    });
});

async function sendMembersUpdate(voiceChannel) {
    if (!voiceChannel) return;

    // Format the member data for the client
    const members = voiceChannel.members
        .filter(member => member.id !== client.user.id)
        .map(member => ({
            id: member.id,
            username: member.user.username,
            display_name: member.displayName,
        }));

    vcMembers = members;

    console.log(`[EVENT] Sending members_update for channel ${voiceChannel.name}. Members: ${members.length}`);
    sendToWs({
        type: 'members_update',
        members: members
    });
}


client.once(Events.ClientReady, readyClient => {
    console.log(`Ready! Logged in as ${readyClient.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === 'join') {
            const voiceChannel = interaction.options.getChannel('channel');

            if (voiceChannel.type !== ChannelType.GuildVoice) {
                await interaction.reply({ content: '❌ Please select a voice channel.', ephemeral: true });
                return;
            }

            try {
                let vcConn = joinVoiceChannel({
                    channelId: voiceChannel.id,
                    guildId: interaction.guildId,
                    adapterCreator: interaction.guild.voiceAdapterCreator,
                    selfDeaf: false
                });

                vcConn.on(VoiceConnectionStatus.Ready, () => {
                    const spkMap = vcConn.receiver.speaking;

                    spkMap.on('start', (userId) => {
                        const user = client.users.cache.get(userId);
                        console.log(`[EVENT]${user.username} started speaking.`);

                        sendToWs({
                            type: 'speaking_update',
                            user_id: userId,
                            is_speaking: true
                        });
                    });

                    spkMap.on('end', (userId) => {
                        const user = client.users.cache.get(userId);
                        console.log(`[EVENT]${user.username} stopped speaking.`);

                        sendToWs({
                            type: 'speaking_update',
                            user_id: userId,
                            is_speaking: false
                        });
                    });
                });

                await interaction.reply(
                    { content: `✅ Joined voice channel: **${voiceChannel.name}**`, flags: 64 },

                );
                console.log(`Joined voice channel: ${voiceChannel.name}`);


            } catch (error) {
                console.error(error);
                await interaction.reply({ content: '❌ Failed to join the voice channel.', flags: 64 });
            }
        } else if (interaction.commandName === 'rejoin') {
            const connection = getVoiceConnection(interaction.guildId);
            if (connection) {
                try {
                    connection.rejoin();
                    await interaction.reply({ content: '✅ Rejoined the voice channel.', flags: 64 });
                    console.log(`Rejoined voice channel: ${connection.joinConfig.channelId}`);
                } catch (error) {
                    console.error(error);
                    await interaction.reply({ content: '❌ Failed to rejoin the voice channel.', flags: 64 });
                }
            } else {
                await interaction.reply({ content: '❌ Not currently connected to a voice channel.', flags: 64 });
            }
        }
    }
});

client.on(Events.GuildMemberUpdate, (oldMember, newMember) => {
    // Check if the old display name is different from the new one
    if (oldMember.displayName !== newMember.displayName) {
        // Log the change and perform your desired action
        console.log(`User ${oldMember.user.tag} changed their display name from "${oldMember.displayName}" to "${newMember.displayName}"`);

        // You can now send an update to your WebSocket client
        const currentConnection = getVoiceConnection(newMember.guild.id);
        if (!currentConnection) return;
        const botChannelId = currentConnection.joinConfig.channelId;
        let voiceChannel = newMember.guild.channels.cache.get(botChannelId);

        if (voiceChannel && voiceChannel.type === ChannelType.GuildVoice) {
            console.log(`[EVENT] [Name change] detected in monitored channel. Updating members.`);
            sendMembersUpdate(voiceChannel);
        }
    }
});

client.on(Events.VoiceStateUpdate, (oldState, newState) => {
    const connection = getVoiceConnection(newState.guild.id);

    if (!connection) return;

    currentConnection = connection;

    const botChannelId = connection.joinConfig.channelId;
    botChannel = botChannelId;

    // Check if the update is relevant to the bot's channel
    const oldChannelId = oldState.channelId;
    const newChannelId = newState.channelId;

    // If a user joins or leaves the bot's current channel
    if (oldChannelId !== newChannelId && (oldChannelId === botChannelId || newChannelId === botChannelId)) {
        let voiceChannel = newState.guild.channels.cache.get(botChannelId);
        if (voiceChannel && voiceChannel.type === ChannelType.GuildVoice) {
            console.log(`[EVENT] Voice state change detected in monitored channel. Updating members.`);
            sendMembersUpdate(voiceChannel);
        }
    }
});

client.on('messageCreate', message => {
    if (message.channelId === refDen && !message.author.bot) {
        const content = message.content;

        const newMsg = {
            command: 'message-received',
            data: {
                messageId: message.id,
                channelId: message.channelId,
                author: message.member.displayName,
                role: message.member.roles.highest.name,
                color: message.member.roles.highest.hexColor,
                content: content,
                timestamp: message.createdTimestamp
            }
        };
        console.log(`[MSG-NEW] ${newMsg.data.messageId}, ${newMsg.data.author}, ${newMsg.data.content}`,
            `(${newMsg.data.role})` + `(${newMsg.data.color})`);
        sendToWs(newMsg);
    }
});

client.on('messageUpdate', (oldMessage, newMessage) => {
    if (newMessage.channelId === refDen && !newMessage.author.bot) {

        const updMsg = {
            command: 'message-updated',
            data: {
                messageId: newMessage.id,
                channelId: newMessage.channelId,
                author: newmessage.member.displayName,
                content: newMessage.content,
                timestamp: newMessage.editedTimestamp
            }
        };
        console.log(`[MSG-EDIT] ${updMsg.data.messageId}, ${updMsg.data.author}, ${updMsg.data.content}`);
        sendToWs(updMsg);
    }
});

client.on('messageDelete', message => {
    if (message.channelId === refDen) {
        const delMsg = {
            command: 'message-deleted',
            data: {
                messageId: message.id,
                author: message.member.displayName
            }
        };
        console.log(`[MSG-DELETE] ${delMsg.data.messageId}, ${delMsg.data.author}`)
        sendToWs(delMsg);
    }
});

async function registerCommands() {
    try {
        await rest.put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), {
            body: [
                new SlashCommandBuilder()
                    .setName('join')
                    .setDescription('Join a voice channel')
                    .addChannelOption(option =>
                        option.setName('channel')
                            .setDescription('The channel to join')
                            .setRequired(true)
                            .addChannelTypes(ChannelType.GuildVoice)
                    ).toJSON(),
                new SlashCommandBuilder()
                    .setName('rejoin')
                    .setDescription('Rejoin the current voice channel')
                    .toJSON(),
            ],
        });
        console.log('Successfully registered application commands.');
    } catch (err) {
        console.error('Error registering commands:', err);
    }
}

client.login(token)
    .then(() => registerCommands())
    .catch(console.error);


//Safe termination on CTRL-C, hopefully speed up the restart process during testing if nothing else (destroy not defined?)
process.on('SIGINT', function () {
    console.log("Exiting COMMBOT - closing active connections.");
    const connections = getVoiceConnections();
    connections.forEach(connection => connection.destroy());
    wss.close(); // Close the WebSocket server
    client.destroy(); // Log out the Discord client
    process.exit();
});